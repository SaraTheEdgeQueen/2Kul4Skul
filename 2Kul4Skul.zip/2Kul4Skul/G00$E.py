
import pygame
pygame.init()

win = pygame.display.set_mode((660,433))

pygame.display.set_caption("First Game")

walkRight = [pygame.image.load('shiba1.png'), pygame.image.load('shiba2.png'), pygame.image.load('shiba3.png'), pygame.image.load('shiba4.png')]
walkLeft = [pygame.image.load('shiba5.png'), pygame.image.load('shiba6.png'), pygame.image.load('shiba7.png'), pygame.image.load('shiba8.png')]
bg = pygame.image.load('bg.jpeg')
doggo = pygame.image.load('shiba.png')

clock = pygame.time.Clock()

bulletSound = pygame.mixer.Sound("Game_bullet.mp3")
hitSound = pygame.mixer.Sound("Game_hit.mp3")

music = pygame.mixer.music.load("Game_music.mp3")
pygame.mixer.music.play(-1)

score = 0

class player(object):
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.isJump = False
        self.left = False
        self.right = False
        self.walkCount = 0
        self.jumpCount = 10
        self.standing = True
        self.hitbox= (self.x + 2, self.y, 50, 83)

    def draw(self, win):
        if self.walkCount + 1 >= 27:
            self.walkCount = 0
        if not self.standing:
            if self.left:
                win.blit(walkLeft[self.walkCount//3%4], (self.x, self.y))
                self.walkCount += 1
            elif self.right:
                win.blit(walkRight[self.walkCount//3%4], (self.x, self.y))
                self.walkCount +=1
        else:
            if self.right:
                win.blit(walkRight[0], (self.x, self.y))
            elif self.left:
                win.blit(walkLeft[0], (self.x, self.y))
            else:
                win.blit(doggo, (self.x, self.y))
        if self.right == True or self.left == True:
            self.hitbox= (self.x, self.y, 84, 83)
        else:
            self.hitbox = (self.x + 2, self.y , 50, 83)
        

    def hit(self):
        self.x = 60
        self.y = 350
        self.walkCount = 0
        font1 = pygame.font.SysFont('comicsans', 100)
        text = font1.render('-5', 1, (255,0,0))
        win.blit(text, (320 - (text.get_width()/2), 200))
        pygame.display.update()
        i = 0
        while i < 300:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i= 301
                    pygame.quit()
            
            
class projectile(object):
    def __init__(self,x,y,radius,color,facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 8 * facing
        
    def draw(self, win):
        pygame.draw.circle(win, self.color, (self.x, self.y), self.radius)
        
class enemy(object):
    walkLeft = [pygame.image.load('cat4.png'),pygame.image.load('cat3.png'),pygame.image.load('cat2.png'),pygame.image.load('cat1.png'),pygame.image.load('cat8.png'),pygame.image.load('cat7.png'),pygame.image.load('cat6.png'),pygame.image.load('cat5.png')]
    walkRight = [pygame.image.load('cat5.png'),pygame.image.load('cat6.png'),pygame.image.load('cat7.png'),pygame.image.load('cat8.png'),pygame.image.load('cat1.png'),pygame.image.load('cat2.png'),pygame.image.load('cat3.png'),pygame.image.load('cat4.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.x, self.end]
        self.walkCount = 0
        self.vel = 3
        self.hitbox= (self.x , self.y , 60, 93)
        self.health = 10
        self.visible = True

    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 24:
                self.walkCount = 0
                
            if self.vel > 0:
                win.blit(self.walkRight[self.walkCount//3], (self.x, self.y))
                self.walkCount += 1
                         
            else:
                win.blit(self.walkRight[self.walkCount//3], (self.x, self.y))
                self.walkCount += 1
            pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect(win, (0,128,0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
            self.hitbox = (self.x, self.y , 60, 93)
            
    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        
    
    

    def hit(self):
        hitSound.play()
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            self.hitbox = (0,0,0,0)
        print('u got slayed Catus OwO')
    
    
def redrawGameWindow():
    win.blit(bg, (0,0))
    doge.draw(win)
    cat.draw(win)
    for bullet in bullets:
        bullet.draw(win)
    text = font.render('Score: ' + str(score), 1, (0,0,0))
    win.blit(text, (390, 10))
        
    pygame.display.update()


#mainloop
font = pygame.font.SysFont('comicsans', 30, True)
doge = player(150, 300, 84,83)
cat = enemy(150, 300, 60, 93, 400)
run = True
shootLoop = 0
bullets = []
while run:
    clock.tick(27)

    if doge.hitbox[1] + doge.hitbox[3] > cat.hitbox[1] and doge.hitbox[1] < cat.hitbox[1] + cat.hitbox[3]:
        if doge.hitbox[0] + doge.hitbox[2] > cat.hitbox[0] and doge.hitbox[0] < cat.hitbox[0] + cat.hitbox[2]:
            doge.hit()
            score -= 5
                
    if shootLoop > 0:
        shootLoop += 1
    if shootLoop > 3:
        shootLoop = 0
        
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    
    for bullet in bullets:
        if bullet.y + bullet.radius > cat.hitbox[1] and bullet.y - bullet.radius < cat.hitbox[1] + cat.hitbox[3]:
            if bullet.x + bullet.radius > cat.hitbox[0] and bullet.x - bullet.radius < cat.hitbox[0] + cat.hitbox[2]:
                hitSound.play()
                cat.hit()
                score +=1
                bullets.remove(bullet)
                
        if bullet.x < 640 and bullet.x > 20:
            bullet.x += bullet.vel
            
        else:
            bullets.remove(bullet)

        
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE] and shootLoop == 0:
        bulletSound.play()
        if doge.left:
            facing = -1
        else:
            facing = 1
        if len(bullets) < 10:
            bullets.append(projectile(round(doge.x + doge.width// 2), round(doge.y + doge.height// 2), 6, (200, 255, 0), facing))
        shootLoop = 1
            
    if keys[pygame.K_LEFT] and doge.x > doge.vel:
        doge.x -= doge.vel
        doge.left = True
        doge.right = False
        doge.standing = False
    elif keys[pygame.K_RIGHT] and doge.x < 660 - doge.width - doge.vel:
        doge.x += doge.vel
        doge.right = True
        doge.left = False
        doge.standing = False
    else: 
        doge.standing = True
        doge.walkCount = 0
        
    if not(doge.isJump):
        if keys[pygame.K_UP]:
            doge.isJump = True
            doge.right = False
            doge.left = False
            doge.walkCount = 0
    else:
        if doge.jumpCount >= -10:
            neg = 1
            if doge.jumpCount < 0:
                neg = -1
            doge.y -= (doge.jumpCount ** 2) * 0.5 * neg
            doge.jumpCount -= 1
        else:
            doge.isJump = False
            doge.jumpCount = 10
            
    redrawGameWindow()

pygame.quit()
